/**
 ******************************************************************************
 * @file    USB_Device/AUDIO_Standalone/Src/usbd_audio_if.c
 * @author  MCD Application Team
 * @brief   USB Device Audio interface file.
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2017 STMicroelectronics International N.V.
 * All rights reserved.</center></h2>
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted, provided that the following conditions are met:
 *
 * 1. Redistribution of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. Neither the name of STMicroelectronics nor the names of other
 *    contributors to this software may be used to endorse or promote products
 *    derived from this software without specific written permission.
 * 4. This software, including modifications and/or derivative works of this
 *    software, must execute solely and exclusively on microcontroller or
 *    microprocessor devices manufactured by or for STMicroelectronics.
 * 5. Redistribution and use of this software other than as permitted under
 *    this license is void and will automatically terminate your rights under
 *    this license.
 *
 * THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY INTELLECTUAL PROPERTY
 * RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT
 * SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 ******************************************************************************
 */
#include "usbd_audio_if.h"
#include "bsp_audio.h"


static int8_t Audio_Init(uint32_t audioFreq, int16_t volume, uint8_t options);
static int8_t Audio_DeInit(uint8_t options);
static int8_t Audio_PlaybackCmd(uint16_t* pbuf, uint32_t size, uint8_t cmd);
static int8_t Audio_VolumeCtl(int16_t volume);
static int8_t Audio_MuteCtl(uint8_t cmd);
static int8_t Audio_PeriodicTC(uint8_t cmd);
static int8_t Audio_GetState(void);

extern AUDIO_STATUS_TypeDef audio_status;
extern USBD_HandleTypeDef USBD_Device;
USBD_AUDIO_ItfTypeDef USBD_AUDIO_fops = {
    Audio_Init,
    Audio_DeInit,
    Audio_PlaybackCmd,
    Audio_VolumeCtl,
    Audio_MuteCtl,
    Audio_PeriodicTC,
    Audio_GetState,
};


/**
 * @brief  Initializes the AUDIO media low layer.
 * @param  AudioFreq: Audio frequency used to play the audio stream.
 * @param  Volume: Initial volume level : 0 (Min) to 100 (Max)
 * @param  options: 1 => Mute On, 0 = Mute off
 * @retval Result of the operation: USBD_OK if all operations are OK else
 * USBD_FAIL
 */
static int8_t Audio_Init(uint32_t audioFreq, int16_t volume, uint8_t options) {
	audio_status.frequency = audioFreq;
	BSP_AUDIO_OUT_Init(volume, audioFreq, options);
	return 0;
	}

/**
 * @brief  De-Initializes the AUDIO media low layer.
 * @param  options: Reserved for future use
 * @retval Result of the operation: USBD_OK if all operations are OK else
 * USBD_FAIL
 */
static int8_t Audio_DeInit(uint8_t options){
	audio_status.playing = 0U;
	BSP_AUDIO_OUT_Stop();
  	return 0;
	}

/**
 * @brief  Handles AUDIO command.
 * @param  pbuf: Pointer to buffer of data to be sent
 * @param  size: Number of data to be sent (in bytes)
 * @param  cmd: Command opcode
 * @retval Result of the operation: USBD_OK if all operations are OK else
 * USBD_FAIL
 */
static int8_t Audio_PlaybackCmd(uint16_t* pbuf, uint32_t size, uint8_t cmd){
	switch (cmd) {
		case AUDIO_CMD_START:
		  BSP_AUDIO_OUT_Play(pbuf, size);
		  audio_status.playing = 1U;
		  break;

		case AUDIO_CMD_PLAY:
		  BSP_AUDIO_OUT_ChangeBuffer(pbuf, size);
		  audio_status.playing = 1U;
		  break;
		}
	return 0;
	}

/**
 * @brief  Controls AUDIO Volume.
 * @param  volume : USB Spec 0x8000 (-128dB) ... 0x0000 (0dB max)
 * @retval Result of the operation: USBD_OK if all operations are OK else
 * USBD_FAIL
 */
static int8_t Audio_VolumeCtl(int16_t vol){
	//BSP_AUDIO_OUT_SetVolume(vol);
	// Volume control implemented in usbd_audio.c
	return 0;
	}

/**
 * @brief  Controls AUDIO Mute.
 * @param  mute: 1 = muted, 0 = unmuted
 * @retval Result of the operation: USBD_OK if all operations are OK else
 * USBD_FAIL
 */
static int8_t Audio_MuteCtl(uint8_t mute){
	BSP_AUDIO_OUT_SetMute(mute);
	return 0;
	}

/**
 * @brief  Audio_PeriodicTC
 * @param  cmd: Command opcode
 * @retval Result of the operation: USBD_OK if all operations are OK else
 * USBD_FAIL
 */
static int8_t Audio_PeriodicTC(uint8_t cmd){
	return 0;
	}

/**
 * @brief  Gets AUDIO State.
 * @param  None
 * @retval Result of the operation: USBD_OK if all operations are OK else
 * USBD_FAIL
 */
static int8_t Audio_GetState(void){
	return 0;
	}

/**
 * @brief  Manages the DMA full Transfer complete event.
 * @param  None
 * @retval None
 */
void BSP_AUDIO_OUT_TransferComplete_CallBack(void)
{
  USBD_AUDIO_Sync(&USBD_Device, AUDIO_OFFSET_FULL);
}

/**
 * @brief  Manages the DMA Half Transfer complete event.
 * @param  None
 * @retval None
 */
void BSP_AUDIO_OUT_HalfTransfer_CallBack(void)
{
  USBD_AUDIO_Sync(&USBD_Device, AUDIO_OFFSET_HALF);
}


